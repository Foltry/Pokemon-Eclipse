SCREEN_WIDTH = 512
SCREEN_HEIGHT = 384
FPS = 60

# Autres constantes à ajouter ici plus tard (chemins, couleurs, etc.)
