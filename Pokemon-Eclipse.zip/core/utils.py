import pygame
import sys

def quit_game():
    pygame.quit()
    sys.exit()
