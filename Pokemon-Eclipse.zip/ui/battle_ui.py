import os
import pygame
import gif_pygame
import json
from PIL import Image
from ui.health_bar import HealthBar
from ui.xp_bar import XPBar

ASSETS = os.path.join("assets", "ui", "battle")
FONTS = os.path.join("assets", "fonts")
SPRITE_DIR = os.path.join("assets", "sprites", "pokemon")
CMD_IMG = pygame.image.load(os.path.join(ASSETS, "cursor_command.png"))

BUTTON_WIDTH = 130
BUTTON_HEIGHT = 46

def get_gif_max_size(gif_path):
    try:
        from PIL import Image
        with Image.open(gif_path) as img:
            max_width = 0
            max_height = 0
            for frame in range(img.n_frames):
                img.seek(frame)
                w, h = img.size
                max_width = max(max_width, w)
                max_height = max(max_height, h)
            # Appliquer un facteur de zoom
            return int(max_width * 2), int(max_height * 2)
    except:
        return 96 * 2, 96 * 2  # Valeur par défaut doublée

def get_command_button(index):
    normal = CMD_IMG.subsurface(pygame.Rect(0, index * BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT))
    selected = CMD_IMG.subsurface(pygame.Rect(BUTTON_WIDTH, index * BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT))
    return normal, selected

class BattleButton:
    def __init__(self, index, pos):
        self.normal, self.selected = get_command_button(index)
        self.rect = self.normal.get_rect(topleft=pos)

    def draw(self, surface, selected=False):
        surface.blit(self.selected if selected else self.normal, self.rect.topleft)

class BattleDialogBox:
    def __init__(self, pos=(0, 288)):
        self.image = pygame.image.load(os.path.join(ASSETS, "dialogue_box.png")).convert_alpha()
        self.rect = self.image.get_rect(topleft=pos)

        font_path = os.path.join(FONTS, "power clear.ttf")
        self.font = pygame.font.Font(font_path, 25)

        self.text_color = (0, 0, 0)
        self.margin_x = 22
        self.margin_y = 25
        self.line_spacing = 2
        self.max_width = 216

    def wrap_text(self, text):
        words = text.split(" ")
        lines = []
        current_line = ""
        for word in words:
            test_line = current_line + word + " "
            if self.font.size(test_line)[0] <= self.max_width:
                current_line = test_line
            else:
                lines.append(current_line.strip())
                current_line = word + " "
        if current_line:
            lines.append(current_line.strip())
        return lines

    def draw(self, surface, text, offset_x=0, offset_y=0, draw_box=True):
        if draw_box:
            surface.blit(self.image, self.rect.topleft)

        lines = self.wrap_text(text)
        y = self.rect.top + self.margin_y + offset_y
        for line in lines:
            txt_surface = self.font.render(line, True, self.text_color)
            surface.blit(txt_surface, (self.rect.left + self.margin_x + offset_x, y))
            y += txt_surface.get_height() + self.line_spacing

def load_battle_ui():
    bg = pygame.image.load(os.path.join(ASSETS, "battle_bg.png")).convert()
    dialog = BattleDialogBox()
    buttons = [
        BattleButton(0, (250, 294)),
        BattleButton(1, (250, 336)),
        BattleButton(2, (376, 294)),
        BattleButton(3, (376, 336))
    ]
    return bg, dialog, buttons

STATUS_PLAYER = None
STATUS_ENEMY = None
_status_loaded = False

def load_status_images():
    global STATUS_PLAYER, STATUS_ENEMY, _status_loaded
    if not _status_loaded:
        STATUS_PLAYER = pygame.image.load(os.path.join(ASSETS, "status_player.png")).convert_alpha()
        STATUS_ENEMY = pygame.image.load(os.path.join(ASSETS, "status_enemy.png")).convert_alpha()
        _status_loaded = True

def resize_gif(gif_obj, size):
    resized_frames = [
        (pygame.transform.scale(frame, size), duration)
        for frame, duration in gif_obj.get_datas()
    ]
    return gif_pygame.GIFPygame(resized_frames)

def load_combat_sprites(ally_id, enemy_id):
    base_ally = pygame.image.load(os.path.join(ASSETS, "base_ally.png")).convert_alpha()
    base_enemy = pygame.image.load(os.path.join(ASSETS, "base_enemy.png")).convert_alpha()

    with open("data/pokemon.json", encoding="utf-8") as f:
        pokemon_data = json.load(f)

    ally = next((p for p in pokemon_data if str(p["id"]).zfill(3) == str(ally_id).zfill(3)), None)
    enemy = next((p for p in pokemon_data if str(p["id"]).zfill(3) == str(enemy_id).zfill(3)), None)

    if not ally or not enemy:
        raise ValueError(f"Impossible de charger les sprites : ally={ally_id}, enemy={enemy_id}")

    ally_path = os.path.join(SPRITE_DIR, ally["sprites"]["back"])
    enemy_path = os.path.join(SPRITE_DIR, enemy["sprites"]["front"])

    ally_size = get_gif_max_size(ally_path)
    enemy_size = get_gif_max_size(enemy_path)

    ally_sprite = gif_pygame.load(ally_path)
    enemy_sprite = gif_pygame.load(enemy_path)

    ally_sprite = resize_gif(ally_sprite, ally_size)
    enemy_sprite = resize_gif(enemy_sprite, enemy_size)

    return (base_ally, base_enemy), (ally_sprite, enemy_sprite)

def draw_combat_scene(
    screen,
    background,
    bases,
    sprites,
    ally_name="",
    enemy_name="",
    ally_hp=100,
    ally_max_hp=100,
    enemy_hp=100,
    enemy_max_hp=100,
    ally_level=5,
    enemy_level=5,
    enemy_gender="?",
    ally_xp=0,
    ally_max_xp=100
):
    load_status_images()
    font_pkm = pygame.font.Font(os.path.join(FONTS, "power clear.ttf"), 27)
    font_pv = pygame.font.Font(os.path.join(FONTS, "power clear bold.ttf"), 27)

    screen.blit(background, (0, 0))

    base_ally, base_enemy = bases
    ally_sprite, enemy_sprite = sprites

    screen.blit(base_ally, (-128, 240))
    screen.blit(base_enemy, (255, 115))

    screen.blit(ally_sprite.blit_ready(), (80, 200))
    if enemy_sprite:
        screen.blit(enemy_sprite.blit_ready(), (340, 90))

    screen.blit(STATUS_PLAYER, (268, 193))
    screen.blit(STATUS_ENEMY, (0, 35))

    enemy_name_text = font_pkm.render(enemy_name, True, (0, 0, 0))

    gender_color = (66, 150, 255) if enemy_gender == "♂" else (255, 105, 180) if enemy_gender == "♀" else (120, 120, 120)
    enemy_gender_text = font_pv.render(enemy_gender, True, gender_color)
    enemy_level_text = font_pv.render(f"Nv.{enemy_level}", True, (51, 51, 51))

    screen.blit(enemy_name_text, (10, 45))
    screen.blit(enemy_gender_text, (55 + enemy_name_text.get_width() + 10, 45))
    screen.blit(enemy_level_text, (85 + enemy_name_text.get_width(), 45))

    ally_name_text = font_pkm.render(ally_name, True, (0, 0, 0))
    ally_level_text = font_pv.render(f"Nv.{ally_level}", True, (51, 51, 51))

    screen.blit(ally_name_text, (305, 205))
    screen.blit(ally_level_text, (450, 205))

    ally_bar = HealthBar((402, 232), (98, 9), ally_max_hp)
    ally_bar.update(ally_hp)
    ally_bar.draw(screen)

    enemy_bar = HealthBar((116, 73), (98, 9), enemy_max_hp)
    enemy_bar.update(enemy_hp)
    enemy_bar.draw(screen)

    hp_text = font_pv.render(f"{ally_hp}/{ally_max_hp}", True, (51, 51, 51))
    hp_text = pygame.transform.scale(hp_text, (hp_text.get_width(), int(hp_text.get_height() * 0.65)))
    screen.blit(hp_text, (410, 246))

    xp_bar = XPBar((308, 267), ally_max_xp)
    xp_bar.update(ally_xp)
    xp_bar.draw(screen)

class AttackUI:
    def __init__(self, pos=(20, 288), spacing=5):
        self.pos = pos
        self.spacing = spacing
        self.moves = []
        self.selected_index = 0
        self.font = pygame.font.Font(os.path.join(FONTS, "power clear.ttf"), 22)
        self.box = pygame.image.load("assets/ui/battle/dialogue_box_bonus.png").convert_alpha()
        self.box_rect = self.box.get_rect(topleft=(260, 294))

    def set_moves(self, moves):
        self.moves = moves[:4] if moves else []
        self.selected_index = 0

    def move_selection_up(self):
        if self.selected_index - 2 >= 0:
            self.selected_index -= 2

    def move_selection_down(self):
        if self.selected_index + 2 < len(self.moves):
            self.selected_index += 2

    def move_selection_left(self):
        if self.selected_index % 2 == 1:
            self.selected_index -= 1

    def move_selection_right(self):
        if self.selected_index % 2 == 0 and self.selected_index + 1 < len(self.moves):
            self.selected_index += 1

    def draw(self, surface):
        surface.blit(self.box, self.box_rect.topleft)

        if not self.moves:
            return

        font = pygame.font.Font(os.path.join(FONTS, "power clear.ttf"), 18)

        # Marges internes de la boîte
        padding_x = 16
        padding_y = 10
        spacing_x = 120
        spacing_y = 40

        start_x = self.box_rect.left + padding_x
        start_y = self.box_rect.top + padding_y

        for i, move in enumerate(self.moves[:4]):
            col = i % 2
            row = i // 2
            x = start_x + col * spacing_x
            y = start_y + row * spacing_y

            name = move["name"]
            type_ = move["type"].capitalize()
            pp = move.get("pp", 0)
            max_pp = move.get("max_pp", pp)

            name_text = f"{name} ({type_})"
            pp_text = f"PP : {pp}/{max_pp}"
            color = (255, 0, 0) if i == self.selected_index else (0, 0, 0)

            name_surf = font.render(name_text, True, color)
            pp_surf = font.render(pp_text, True, color)

            surface.blit(name_surf, (x, y))
            surface.blit(pp_surf, (x, y + name_surf.get_height() + 2))

    def get_selected_move(self):
        if 0 <= self.selected_index < len(self.moves):
            return self.moves[self.selected_index]
        return None
